Shelf Operation Explanations
====================

Orders in one shelf are stored in a PriorityQueue which sorts orders by their expiration time: first order in the queue has the nearest expiration time.

The shelf has two metrics:

1. size of the queue
2. numPickedUp: number of pickedup order which are still in the queue

At the same time, one LinkedBlockingDeque is used to track orders in all shelves.

Pickup Order from Shelf
----
take one order from LinkedBlockingDeque. 
If the order can be picked up at the moment, mark the order in shelf's PriorityQueue as pickedup and numPickedUp++. The order still stays in the PriorityQueue of the shelf.

If no order from LinkedBlockingDeque, wait until timeout.


Add Order into Shelf
----

Before adding order into shelf, shelf will do self-cleanup (removeStaleOrdersIfNeeded) to remove pickuped order or expired order from the PriorityQueue

the self-cleanup function checks the first order from the PriorityQueue:

1. if the order is marked as pickedup, remove the order from PriorityQueue, and numPickedUp--
2. if the order expires, remove the order from PriorityQueue
3. if the order meets any of the above 2 conditions, continue to look at next order; otherwise, stop.

> NOTE: it's possible that one pickedup item is not the first, and the fist order is also not expired. In this case, the pickedup order will not be removed at the moment.

After self-cleanup, if the order fits shelf's type and shelf has remaining capacity (orders.size - numPickedUp), order will be added into the PriorityQueue.

At the same time, order will also be added into LinkedBlockingDeque in the kitchen.

> NOTE: is it better to use PriorityBlockingQueue?

> Note: Only removeStaleOrdersIfNeeded will remove orders physically from PriorityQueue in the shelf. 


